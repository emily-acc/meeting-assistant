# Meeting Schedule Assistant

A web-based meeting schedule assistant that parses WeChat meeting invitations and integrates with Google Calendar and TimeTree.

## Features
- Parse Webex, Zoom, and Teams meeting invitations
- Batch import multiple meetings
- Sync with Google Calendar
- TimeTree integration
- Browser notifications
- Persistent storage

## Setup
1. Get Gemini API Key from https://aistudio.google.com
2. Deploy to Vercel with GEMINI_API_KEY environment variable
3. Open the app and start using

## Deployment
Deploy to Vercel with one click, then set environment variable GEMINI_API_KEY
