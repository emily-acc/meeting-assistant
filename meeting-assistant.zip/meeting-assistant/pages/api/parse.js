export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { text } = req.body;
  const apiKey = process.env.GEMINI_API_KEY;

  if (!apiKey) {
    return res.status(500).json({ error: 'API key not configured' });
  }

  try {
    const prompt = `分析以下會議邀請文字，提取所有會議訊息。對於每個會議，返回一個 JSON 物件，包含以下欄位（都是必需的）：
- title: 會議標題或主題
- startTime: ISO 8601 格式的開始時間
- duration: 持續時間（分鐘），如果不知道則為 60
- platform: 平台類型（webex/zoom/teams/other）
- link: 會議連結（如果有）
- password: 會議密碼（如果有，否則為空字符串）
- hostKey: 主持人金鑰或密碼（如果有，否則為空字符串）
- description: 簡短描述

支援的格式包括：
1. Webex 邀請：提取主題、時間、密碼、主持人金鑰、台灣電話等
2. Zoom 邀請：提取主題、時間、會議 ID、密碼等
3. Teams 邀請：提取主題、時間、加入連結等
4. 自由文本描述：識別日期時間和事件名稱

返回格式：
{
  "events": [
    { "title": "...", "startTime": "...", ... },
    ...
  ]
}

文字内容：
${text}`;

    const response = await fetch(
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent',
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          contents: [
            {
              parts: [{ text: prompt }],
            },
          ],
        }),
      }
    );

    const data = await response.json();
    const content = data.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!content) {
      return res.status(500).json({ error: 'No response from API' });
    }

    try {
      const jsonMatch = content.match(/\{[\s\S]*"events"[\s\S]*\}/);
      const result = jsonMatch ? JSON.parse(jsonMatch[0]) : { events: [] };
      
      return res.status(200).json({
        events: (result.events || []).map(e => ({
          title: e.title || '會議',
          startTime: e.startTime || new Date().toISOString(),
          duration: e.duration || 60,
          platform: e.platform || 'other',
          link: e.link || '',
          password: e.password || '',
          hostKey: e.hostKey || '',
          description: e.description || '',
        })),
      });
    } catch (parseError) {
      return res.status(500).json({ error: 'Failed to parse API response' });
    }
  } catch (error) {
    return res.status(500).json({ error: error.message });
  }
}
