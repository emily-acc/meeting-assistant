import { useState, useEffect } from 'react';
import styles from '../styles/Home.module.css';

export default function Home() {
  const [view, setView] = useState('calendar');
  const [events, setEvents] = useState([]);
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [calendarView, setCalendarView] = useState('week');
  const [showTimeTree, setShowTimeTree] = useState(true);
  const [timeTreeEvents, setTimeTreeEvents] = useState([]);
  const [timeTreeUrl, setTimeTreeUrl] = useState('');
  const [notificationsEnabled, setNotificationsEnabled] = useState(false);

  // Load from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('meetingEvents');
    if (saved) setEvents(JSON.parse(saved));
    
    const savedTimeTree = localStorage.getItem('timeTreeUrl');
    if (savedTimeTree) setTimeTreeUrl(savedTimeTree);
    
    checkNotificationPermission();
  }, []);

  // Save to localStorage
  useEffect(() => {
    localStorage.setItem('meetingEvents', JSON.stringify(events));
  }, [events]);

  useEffect(() => {
    localStorage.setItem('timeTreeUrl', timeTreeUrl);
  }, [timeTreeUrl]);

  const parseEvents = async () => {
    if (!input.trim()) return;
    setLoading(true);

    try {
      const res = await fetch('/api/parse', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: input })
      });

      if (!res.ok) throw new Error('Parse failed');
      const data = await res.json();

      if (data.events && Array.isArray(data.events)) {
        const newEvents = data.events.map(e => ({
          ...e,
          id: Date.now() + Math.random(),
          type: 'meeting'
        }));
        setEvents([...events, ...newEvents]);
        setInput('');
        setView('calendar');
      }
    } catch (error) {
      alert('解析失敗: ' + error.message);
    } finally {
      setLoading(false);
    }
  };

  const getWeekDates = (date) => {
    const start = new Date(date);
    start.setDate(date.getDate() - date.getDay());
    return Array.from({ length: 7 }, (_, i) => new Date(start.getTime() + i * 86400000));
  };

  const getEventsForDate = (date) => {
    return events.filter(e => {
      const eDate = new Date(e.startTime).toDateString();
      return eDate === date.toDateString();
    });
  };

  const deleteEvent = (id) => {
    setEvents(events.filter(e => e.id !== id));
  };

  const openGoogleCalendar = (event) => {
    const startTime = new Date(event.startTime).toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
    const endTime = new Date(new Date(event.startTime).getTime() + (event.duration || 60) * 60000).toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
    
    const url = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(event.title)}&dates=${startTime}/${endTime}&details=${encodeURIComponent(event.link || '')}&authuser=sbndy0609@gmail.com`;
    window.open(url, '_blank');
  };

  const checkNotificationPermission = () => {
    if ('Notification' in window) {
      setNotificationsEnabled(Notification.permission === 'granted');
    }
  };

  const enableNotifications = async () => {
    if ('Notification' in window) {
      const permission = await Notification.requestPermission();
      setNotificationsEnabled(permission === 'granted');
    }
  };

  const formatDate = (date) => {
    return date.toLocaleDateString('zh-TW', { month: '2-digit', day: '2-digit' });
  };

  const weekDates = getWeekDates(selectedDate);
  const todayEvents = getEventsForDate(selectedDate);

  return (
    <div style={styles.container}>
      <style>{`
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Arial, sans-serif; background: #f5f5f5; }
        .app { background: white; min-height: 100vh; display: flex; flex-direction: column; }
        .header { background: linear-gradient(135deg, #1C2B4A 0%, #2a3f5f 100%); color: white; padding: 16px; text-align: center; }
        .header h1 { font-size: 20px; margin: 0; }
        .tabs { display: flex; border-bottom: 1px solid #ddd; }
        .tab { flex: 1; padding: 12px; text-align: center; border: none; background: white; cursor: pointer; font-size: 12px; }
        .tab.active { color: #1C2B4A; border-bottom: 3px solid #1C2B4A; }
        .content { flex: 1; padding: 16px; }
        .week-view { display: flex; gap: 8px; overflow-x: auto; margin-bottom: 16px; }
        .day-btn { padding: 12px 16px; border: 1px solid #ddd; border-radius: 8px; cursor: pointer; min-width: 60px; text-align: center; font-size: 12px; }
        .day-btn.active { background: #1C2B4A; color: white; }
        .event-list { display: flex; flex-direction: column; gap: 12px; }
        .event-card { border: 1px solid #ddd; border-radius: 8px; padding: 12px; background: #fafafa; }
        .event-time { font-weight: bold; color: #1C2B4A; font-size: 14px; }
        .event-title { margin: 4px 0; font-size: 14px; }
        .event-buttons { display: flex; gap: 8px; margin-top: 8px; flex-wrap: wrap; }
        .btn { padding: 6px 12px; border: none; border-radius: 4px; cursor: pointer; font-size: 12px; }
        .btn-primary { background: #1C2B4A; color: white; }
        .btn-secondary { background: #e0e0e0; }
        .textarea { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 8px; font-size: 14px; min-height: 100px; }
        .input-section { display: flex; flex-direction: column; gap: 12px; }
        .settings { display: flex; flex-direction: column; gap: 12px; }
        .setting-item { padding: 12px; background: #fafafa; border-radius: 8px; border: 1px solid #ddd; }
        .nav { display: flex; position: fixed; bottom: 0; width: 100%; border-top: 1px solid #ddd; background: white; }
        .nav-item { flex: 1; padding: 12px; text-align: center; cursor: pointer; border: none; background: white; font-size: 12px; }
        .nav-item.active { color: #1C2B4A; border-top: 3px solid #1C2B4A; }
      `}</style>
      
      <div className="app">
        <div className="header">
          <h1>📅 會議行程助理</h1>
        </div>

        <div className="tabs">
          <button className={`tab ${view === 'calendar' ? 'active' : ''}`} onClick={() => setView('calendar')}>📅 行事曆</button>
          <button className={`tab ${view === 'add' ? 'active' : ''}`} onClick={() => setView('add')}>➕ 新增</button>
          <button className={`tab ${view === 'settings' ? 'active' : ''}`} onClick={() => setView('settings')}>⚙️ 設定</button>
        </div>

        <div className="content" style={{ paddingBottom: '80px' }}>
          {view === 'calendar' && (
            <>
              <div style={{ marginBottom: '16px' }}>
                <button className="btn btn-secondary" onClick={() => {
                  const d = new Date(selectedDate);
                  d.setDate(d.getDate() - 7);
                  setSelectedDate(d);
                }}>← 上週</button>
                <button className="btn btn-secondary" onClick={() => setSelectedDate(new Date())} style={{ marginLeft: '8px' }}>今</button>
                <button className="btn btn-secondary" onClick={() => {
                  const d = new Date(selectedDate);
                  d.setDate(d.getDate() + 7);
                  setSelectedDate(d);
                }} style={{ marginLeft: '8px' }}>下週 →</button>
              </div>
              
              <div className="week-view">
                {weekDates.map(date => (
                  <button 
                    key={date.toISOString()}
                    className={`day-btn ${date.toDateString() === selectedDate.toDateString() ? 'active' : ''}`}
                    onClick={() => setSelectedDate(new Date(date))}
                  >
                    {formatDate(date)}
                  </button>
                ))}
              </div>

              <h3>{selectedDate.toLocaleDateString('zh-TW')}</h3>
              {todayEvents.length === 0 ? (
                <p>今日無行程</p>
              ) : (
                <div className="event-list">
                  {todayEvents.map(e => (
                    <div key={e.id} className="event-card" style={{ borderLeft: `4px solid ${e.platform === 'webex' ? '#00BFB3' : e.platform === 'zoom' ? '#2D8CFF' : '#6264A7'}` }}>
                      <div className="event-time">{new Date(e.startTime).toLocaleTimeString('zh-TW', { hour: '2-digit', minute: '2-digit' })}</div>
                      <div className="event-title">{e.title}</div>
                      {e.platform && <div style={{ fontSize: '12px', color: '#666' }}>📱 {e.platform}</div>}
                      <div className="event-buttons">
                        {e.link && <button className="btn btn-primary" onClick={() => window.open(e.link, '_blank')}>🔗 加入</button>}
                        {e.password && <button className="btn btn-secondary" onClick={() => navigator.clipboard.writeText(e.password)}>🔑 密碼</button>}
                        {e.hostKey && <button className="btn btn-secondary" onClick={() => navigator.clipboard.writeText(e.hostKey)}>👑 金鑰</button>}
                        <button className="btn btn-secondary" onClick={() => openGoogleCalendar(e)}>📅 Google</button>
                        <button className="btn btn-secondary" onClick={() => deleteEvent(e.id)}>🗑 刪除</button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </>
          )}

          {view === 'add' && (
            <div className="input-section">
              <textarea 
                className="textarea"
                placeholder="貼入 WeChat 會議邀請、Email、或任何會議訊息..."
                value={input}
                onChange={(e) => setInput(e.target.value)}
              />
              <button 
                className="btn btn-primary" 
                onClick={parseEvents}
                disabled={loading}
              >
                {loading ? '解析中...' : '解析並加入行事曆'}
              </button>
              {!notificationsEnabled && (
                <button className="btn btn-secondary" onClick={enableNotifications}>
                  🔔 開啟提醒通知
                </button>
              )}
              {notificationsEnabled && <p style={{ color: 'green' }}>✅ 已開啟提醒通知</p>}
            </div>
          )}

          {view === 'settings' && (
            <div className="settings">
              <div className="setting-item">
                <h4>TimeTree iCal 網址</h4>
                <input 
                  type="text"
                  placeholder="https://timetr.ee/..."
                  value={timeTreeUrl}
                  onChange={(e) => setTimeTreeUrl(e.target.value)}
                  style={{ width: '100%', padding: '8px', borderRadius: '4px', border: '1px solid #ddd', marginTop: '8px' }}
                />
              </div>
              <div className="setting-item">
                <label>
                  <input 
                    type="checkbox" 
                    checked={showTimeTree} 
                    onChange={(e) => setShowTimeTree(e.target.checked)}
                  />
                  {' '}顯示 TimeTree 個人行程
                </label>
              </div>
              <div className="setting-item">
                <p>✅ Google Calendar 帳號: sbndy0609@gmail.com</p>
              </div>
            </div>
          )}
        </div>

        <div className="nav">
          <button className={`nav-item ${view === 'calendar' ? 'active' : ''}`} onClick={() => setView('calendar')}>📅</button>
          <button className={`nav-item ${view === 'add' ? 'active' : ''}`} onClick={() => setView('add')}>➕</button>
          <button className={`nav-item ${view === 'settings' ? 'active' : ''}`} onClick={() => setView('settings')}>⚙️</button>
        </div>
      </div>
    </div>
  );
}
